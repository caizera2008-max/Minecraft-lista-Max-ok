package com.example.mclist

data class Block(val id: String, val name: String, val color: Int)

private fun b(id: String, name: String, rgb: Int) = Block(id, name, 0xFF000000.toInt() or rgb)

private val DYES = listOf(
    Triple("white", "branco" to "branca", 0xE9ECEC),
    Triple("orange", "laranja" to "laranja", 0xF07613),
    Triple("magenta", "magenta" to "magenta", 0xBD44B3),
    Triple("light_blue", "azul-claro" to "azul-clara", 0x3AAFD9),
    Triple("yellow", "amarelo" to "amarela", 0xF8C527),
    Triple("lime", "verde-limão" to "verde-limão", 0x70B919),
    Triple("pink", "rosa" to "rosa", 0xED8DAC),
    Triple("gray", "cinza" to "cinza", 0x3E4447),
    Triple("light_gray", "cinza-claro" to "cinza-clara", 0x8E8E86),
    Triple("cyan", "ciano" to "ciano", 0x158991),
    Triple("purple", "roxo" to "roxa", 0x792AAC),
    Triple("blue", "azul" to "azul", 0x35399D),
    Triple("brown", "marrom" to "marrom", 0x724728),
    Triple("green", "verde" to "verde", 0x546D1B),
    Triple("red", "vermelho" to "vermelha", 0xA12722),
    Triple("black", "preto" to "preta", 0x141519),
)

private val BASE = listOf(
    // Pedras
    b("stone", "Pedra", 0x7D7D7D), b("cobblestone", "Pedregulho", 0x6E6E6E),
    b("smooth_stone", "Pedra lisa", 0x9A9A9A), b("stone_bricks", "Tijolos de pedra", 0x777777),
    b("deepslate", "Ardósia", 0x4D4D52), b("cobbled_deepslate", "Pedregulho de ardósia", 0x515156),
    b("granite", "Granito", 0x9A6B58), b("diorite", "Diorito", 0xBDBDBD), b("andesite", "Andesito", 0x8A8A8A),
    b("bricks", "Tijolos", 0x96503F), b("terracotta", "Terracota", 0x986A4F),
    b("sandstone", "Arenito", 0xD8CB9B), b("red_sandstone", "Arenito vermelho", 0xB5602A),
    b("obsidian", "Obsidiana", 0x14111F),
    // Terra e areia
    b("dirt", "Terra", 0x866043), b("grass_block", "Bloco de grama", 0x5F9B3C), b("podzol", "Podzol", 0x6B4A2B),
    b("mud", "Lama", 0x3C3A3F), b("clay", "Argila", 0xA0A6B4), b("sand", "Areia", 0xDBD3A0),
    b("red_sand", "Areia vermelha", 0xB5622B), b("gravel", "Cascalho", 0x837F7E),
    b("snow_block", "Bloco de neve", 0xF8FEFE), b("ice", "Gelo", 0x91B8FF), b("packed_ice", "Gelo compactado", 0x7FA5E6),
    // Nether, End, oceano
    b("netherrack", "Netherrack", 0x6F3535), b("nether_bricks", "Tijolos do Nether", 0x2D161A),
    b("soul_sand", "Areia das almas", 0x54402F), b("basalt", "Basalto", 0x4B4B50),
    b("blackstone", "Pedra negra", 0x2A2429), b("end_stone", "Pedra do End", 0xDDDF9E),
    b("glowstone", "Pedra luminosa", 0xD9A85A), b("prismarine", "Prismarina", 0x63A896),
    b("sea_lantern", "Lanterna do mar", 0xCFE5DC),
    // Tábuas
    b("oak_planks", "Tábuas de carvalho", 0xB8945F), b("spruce_planks", "Tábuas de pinheiro", 0x7A5A34),
    b("birch_planks", "Tábuas de bétula", 0xC8B77A), b("jungle_planks", "Tábuas da selva", 0xB88764),
    b("acacia_planks", "Tábuas de acácia", 0xA95A32), b("dark_oak_planks", "Tábuas de carvalho escuro", 0x4B3219),
    b("mangrove_planks", "Tábuas de mangue", 0x7B3A3A), b("cherry_planks", "Tábuas de cerejeira", 0xE2B3A9),
    b("bamboo_planks", "Tábuas de bambu", 0xC9B04D), b("crimson_planks", "Tábuas carmesim", 0x6A2B44),
    b("warped_planks", "Tábuas distorcidas", 0x2B6C62),
    // Troncos e folhas
    b("oak_log", "Tronco de carvalho", 0x6B5230), b("spruce_log", "Tronco de pinheiro", 0x4A331C),
    b("birch_log", "Tronco de bétula", 0xD8D5C9), b("jungle_log", "Tronco da selva", 0x584419),
    b("acacia_log", "Tronco de acácia", 0x676157), b("dark_oak_log", "Tronco de carvalho escuro", 0x3C2D18),
    b("cherry_log", "Tronco de cerejeira", 0x3A2A2F), b("mangrove_log", "Tronco de mangue", 0x5A3A2E),
    b("oak_leaves", "Folhas de carvalho", 0x3E7A2A),
    // Vidro
    b("glass", "Vidro", 0xC8E6F0),
    // Minérios e metais
    b("iron_block", "Bloco de ferro", 0xD8D8D8), b("gold_block", "Bloco de ouro", 0xFAEC4E),
    b("diamond_block", "Bloco de diamante", 0x62EDE4), b("emerald_block", "Bloco de esmeralda", 0x2BD05A),
    b("lapis_block", "Bloco de lápis-lazúli", 0x1F4BA5), b("redstone_block", "Bloco de redstone", 0xAB1B09),
    b("coal_block", "Bloco de carvão", 0x101010), b("copper_block", "Bloco de cobre", 0xC06C4F),
    b("netherite_block", "Bloco de netherita", 0x423E41), b("quartz_block", "Bloco de quartzo", 0xEBE5DE),
    b("amethyst_block", "Bloco de ametista", 0x8561BF),
    // Diversos
    b("bookshelf", "Estante de livros", 0x7B5E3A), b("crafting_table", "Bancada de trabalho", 0x9A6C3C),
    b("furnace", "Fornalha", 0x7A7A7A), b("chest", "Baú", 0xA06F2D), b("torch", "Tocha", 0xF2B63B),
    b("hay_block", "Fardo de feno", 0xC29B13), b("pumpkin", "Abóbora", 0xC47516),
    b("melon", "Melancia", 0x8FA82A), b("tnt", "TNT", 0xD32F2F),
    b("slime_block", "Bloco de slime", 0x7FBF5E), b("honey_block", "Bloco de mel", 0xE8A82A),
)

val BLOCKS: List<Block> = buildList {
    addAll(BASE)
    DYES.forEach { (id, n, c) -> add(b("${id}_wool", "Lã ${n.second}", c)) }
    DYES.forEach { (id, n, c) -> add(b("${id}_concrete", "Concreto ${n.first}", c)) }
}
